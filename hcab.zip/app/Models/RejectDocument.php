<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RejectDocument extends Model
{
    protected $table = 'reject_documents';
    protected $guarded = [];
}
