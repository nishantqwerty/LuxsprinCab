<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Stops extends Model
{
    protected $table = 'route_stops';
    protected $guarded = [];
}
