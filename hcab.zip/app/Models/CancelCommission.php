<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CancelCommission extends Model
{
    protected $table = 'cancel_commission';
    protected $guarded = [];
}
