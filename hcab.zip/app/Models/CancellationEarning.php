<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CancellationEarning extends Model
{
    protected $table = 'cancellation_earnings';
    protected $guarded = [];
}
