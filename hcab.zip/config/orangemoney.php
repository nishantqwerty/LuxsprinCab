<?php

return [
    'auth_header'  => env('OM_AUTH_HEADER', ''),
    'merchant_key' => env('OM_MERCHANT_KEY', ''),
    'return_url'   => env('OM_RETURN_URL', ''),
    'cancel_url'   => env('OM_CANCEL_URL', ''),
    'notif_url'    => env('OM_NOTIf_URL', '')
];
